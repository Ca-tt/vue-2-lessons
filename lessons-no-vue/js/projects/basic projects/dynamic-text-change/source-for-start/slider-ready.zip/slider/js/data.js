let data = [
	{
		title: "Comfy Maxer 1",
		subtitle: "A new way to get comfortable shoes 1",
	},
	{
		title: "Comfy Maxer 2",
		subtitle: "A new way to get comfortable shoes 2",
	},
	{
		title: "Comfy Maxer 3",
		subtitle: "A new way to get comfortable shoes 3",
	},
	{
		title: "Comfy Maxer 4",
		subtitle: "A new way to get comfortable shoes 4",
	},
	{
		title: "Comfy Maxer 5",
		subtitle: "A new way to get comfortable shoes 5",
	},
];
